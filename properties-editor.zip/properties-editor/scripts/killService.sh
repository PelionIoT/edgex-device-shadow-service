#!/bin/sh

stop_service() 
{
    cd ${HOME}/service
    ./killService.sh
}

main()
{
    stop_service $*
}

main $*
