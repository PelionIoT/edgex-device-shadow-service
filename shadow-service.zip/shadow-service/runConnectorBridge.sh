#!/bin/sh
./start.sh &
