#!/bin/sh

rm -f ./logs/*.log 2> /dev/null
mkdir -p ./logs
cd /home/arm/shadow-service/target
java -Dmax-thread-pool-size=30 -Dconfig_file="../conf/service.properties" -jar mbed-edgex-shadow-service-1.0.war > ../logs/shadow-service.log 2>&1 &
