#!/bin/sh

cd /home/arm/shadow-service
./invokeShadowService.sh &
