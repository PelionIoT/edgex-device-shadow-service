#!/bin/sh

cd /home/arm/shadow-service
./runShadowService.sh &
